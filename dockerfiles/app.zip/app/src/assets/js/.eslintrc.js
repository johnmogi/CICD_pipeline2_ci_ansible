module.exports = {
	extends: [ "reverentgeek" ],
	env: {
		browser: true
	}
};